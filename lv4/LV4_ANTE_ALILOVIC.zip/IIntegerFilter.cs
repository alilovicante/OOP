﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lv4
{
    public interface IIntegerFilter
    {
        bool IsValid(int number);
    }
}
